-- Sadece place_id ve kendi takip alanlarımız saklanır; işletme bilgileri Google'dan canlı çekilir.
CREATE TABLE IF NOT EXISTS leads (
  place_id   TEXT PRIMARY KEY,
  slug       TEXT UNIQUE NOT NULL,
  sector     TEXT NOT NULL,
  area       TEXT,
  city       TEXT,
  score      REAL DEFAULT 0,
  wa         INTEGER DEFAULT 0,
  site_type  TEXT DEFAULT '',
  status     TEXT DEFAULT 'yeni',
  note       TEXT DEFAULT '',
  views      INTEGER DEFAULT 0,
  last_view  TEXT,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
CREATE TABLE IF NOT EXISTS domains (
  hostname TEXT PRIMARY KEY,
  slug     TEXT NOT NULL
);
