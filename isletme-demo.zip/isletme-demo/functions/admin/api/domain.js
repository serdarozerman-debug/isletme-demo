import { json, nowIso } from "../../_lib/util.js";

// Satış sonrası: işletmenin alan adını slug'a bağlar. Alan adını Cloudflare Pages'e
// "Custom domain" olarak eklemek ayrıca gerekir.
export async function onRequestPost({ request, env }) {
  const b = await request.json().catch(() => ({}));
  const host = String(b.hostname || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/.*$/, "");
  if (!b.slug || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(host)) return json({ error: "Geçerli bir alan adı girin (ör. patimama.com)." }, 400);
  await env.DB.batch([
    env.DB.prepare("INSERT OR REPLACE INTO domains (hostname, slug) VALUES (?, ?)").bind(host, b.slug),
    env.DB.prepare("UPDATE leads SET status = 'satildi', updated_at = ? WHERE slug = ?").bind(nowIso(), b.slug),
  ]);
  return json({ ok: true, hostname: host });
}
