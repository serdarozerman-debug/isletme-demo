import { SECTORS } from "../../_lib/sectors.js";
import { textSearch } from "../../_lib/places.js";
import { json, slugify, shortHash, waNumber, siteType, score, nowIso } from "../../_lib/util.js";

// Arayüz her ilçe için ayrı çağırır (Cloudflare ücretsiz plandaki istek başı alt-istek sınırına takılmamak için).
export async function onRequestPost({ request, env }) {
  const b = await request.json().catch(() => ({}));
  const sectorKey = SECTORS[b.sector] ? b.sector : "diger";
  const term = sectorKey === "diger" ? (b.customQuery || "").trim() : SECTORS[sectorKey].query;
  const area = (b.area || "").trim(), city = (b.city || "").trim();
  if (!term) return json({ error: "Arama terimi boş. Sektör seçin ya da kendi terminizi yazın." }, 400);
  if (!area && !city) return json({ error: "Şehir ya da ilçe girin." }, 400);
  if (!env.PLACES_API_KEY) return json({ error: "PLACES_API_KEY tanımlı değil." }, 500);

  const query = [term, area, city].filter(Boolean).join(" ");
  let places;
  try { places = await textSearch(env, query); }
  catch (e) { return json({ error: e.message }, 502); }

  const minReviews = Number(b.minReviews) || 0;
  let cands = places.filter((p) => {
    if (p.businessStatus !== "OPERATIONAL") return false;
    if ((p.userRatingCount || 0) < minReviews) return false;
    const t = siteType(p.websiteUri);
    return t === "" || (b.includeSocial !== false && t !== "site");
  });
  if (b.mobileOnly) cands = cands.filter((p) => waNumber(p.internationalPhoneNumber));
  if (!cands.length) return json({ query, total: places.length, results: [] });

  const ids = cands.map((p) => p.id);
  const existing = await env.DB.prepare(
    `SELECT place_id, slug, status, views, note FROM leads WHERE place_id IN (${ids.map(() => "?").join(",")})`,
  ).bind(...ids).all();
  const known = new Map(existing.results.map((r) => [r.place_id, r]));

  const now = nowIso(), inserts = [], results = [];
  for (const p of cands) {
    const name = p.displayName?.text || "";
    let row = known.get(p.id);
    if (row?.status === "ret") continue;
    const wa = waNumber(p.internationalPhoneNumber);
    const st = siteType(p.websiteUri);
    const sc = score(p);
    if (!row) {
      const slug = `${slugify(name) || "isletme"}-${slugify(area || city)}-${await shortHash(p.id)}`;
      inserts.push(env.DB.prepare(
        "INSERT OR IGNORE INTO leads (place_id, slug, sector, area, city, score, wa, site_type, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,'yeni',?,?)",
      ).bind(p.id, slug, sectorKey, area, city, sc, wa ? 1 : 0, st, now, now));
      row = { slug, status: "yeni", views: 0, note: "", isNew: true };
    }
    results.push({
      slug: row.slug, status: row.status, views: row.views, note: row.note, isNew: !!row.isNew,
      name, area: area || city, phone: p.nationalPhoneNumber || "", wa, siteType: st,
      rating: p.rating || null, reviews: p.userRatingCount || 0, score: sc,
      address: p.formattedAddress || "", maps: p.googleMapsUri || "",
    });
  }
  if (inserts.length) await env.DB.batch(inserts);
  results.sort((a, b) => b.score - a.score);
  return json({ query, total: places.length, results });
}
