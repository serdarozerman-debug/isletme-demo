import { SECTORS } from "../../_lib/sectors.js";
import { json } from "../../_lib/util.js";
export const onRequestGet = () => json(Object.entries(SECTORS).map(([key, s]) => ({ key, label: s.label })));
