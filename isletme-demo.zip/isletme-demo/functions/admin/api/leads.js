import { json, nowIso } from "../../_lib/util.js";

const STATUSES = ["yeni", "arandi", "ilgili", "teklif", "satildi", "ret"];

export async function onRequestGet({ request, env }) {
  const u = new URL(request.url);
  const status = u.searchParams.get("status") || "", sector = u.searchParams.get("sector") || "";
  const { results } = await env.DB.prepare(
    `SELECT slug, sector, area, city, score, wa, site_type, status, note, views, last_view, created_at
     FROM leads WHERE (?1 = '' OR status = ?1) AND (?2 = '' OR sector = ?2)
     ORDER BY (status = 'ret'), views DESC, score DESC LIMIT 500`,
  ).bind(status, sector).all();
  const counts = await env.DB.prepare("SELECT status, COUNT(*) n FROM leads GROUP BY status").all();
  return json({ leads: results, counts: Object.fromEntries(counts.results.map((r) => [r.status, r.n])) });
}

export async function onRequestPatch({ request, env }) {
  const b = await request.json().catch(() => ({}));
  if (!b.slug) return json({ error: "slug eksik" }, 400);
  if (b.status && !STATUSES.includes(b.status)) return json({ error: "Geçersiz durum" }, 400);
  await env.DB.prepare(
    "UPDATE leads SET status = COALESCE(?, status), note = COALESCE(?, note), updated_at = ? WHERE slug = ?",
  ).bind(b.status ?? null, b.note ?? null, nowIso(), b.slug).run();
  return json({ ok: true });
}
