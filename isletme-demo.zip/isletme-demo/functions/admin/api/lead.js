import { placeDetails, CONTACT_FIELDS } from "../../_lib/places.js";
import { json, waNumber } from "../../_lib/util.js";

// Kayıtlı bir lead'in iletişim bilgisini Google'dan anlık getirir (saklanmaz).
export async function onRequestGet({ request, env }) {
  const slug = new URL(request.url).searchParams.get("slug");
  const row = await env.DB.prepare("SELECT place_id FROM leads WHERE slug = ?").bind(slug).first();
  if (!row) return json({ error: "Bulunamadı" }, 404);
  const p = await placeDetails(env, row.place_id, CONTACT_FIELDS);
  if (!p) return json({ error: "Google'dan bilgi alınamadı" }, 502);
  return json({
    name: p.displayName?.text || "", phone: p.nationalPhoneNumber || "",
    wa: waNumber(p.internationalPhoneNumber), address: p.formattedAddress || "", maps: p.googleMapsUri || "",
  });
}
