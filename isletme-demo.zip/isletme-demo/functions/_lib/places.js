const GOOGLE = "https://places.googleapis.com/v1";
const base = (env) => env.PLACES_BASE || GOOGLE; // test için değiştirilebilir

const SEARCH_FIELDS = [
  "places.id", "places.displayName", "places.formattedAddress",
  "places.nationalPhoneNumber", "places.internationalPhoneNumber", "places.websiteUri",
  "places.rating", "places.userRatingCount", "places.googleMapsUri", "places.businessStatus",
  "nextPageToken",
].join(",");

export const DETAIL_FIELDS = [
  "id", "displayName", "formattedAddress", "nationalPhoneNumber", "internationalPhoneNumber",
  "rating", "userRatingCount", "googleMapsUri", "regularOpeningHours.weekdayDescriptions",
  "currentOpeningHours.openNow", "businessStatus", "photos", "reviews", "primaryTypeDisplayName",
].join(",");

export const CONTACT_FIELDS = "displayName,formattedAddress,nationalPhoneNumber,internationalPhoneNumber,googleMapsUri";

// Bir sorgu en fazla 3 sayfa / 60 sonuç döner (Google sınırı).
export async function textSearch(env, query) {
  let token, out = [];
  for (let i = 0; i < 3; i++) {
    const body = { textQuery: query, languageCode: "tr", regionCode: "TR", pageSize: 20 };
    if (token) body.pageToken = token;
    const r = await fetch(`${base(env)}/places:searchText`, {
      method: "POST",
      headers: { "content-type": "application/json", "X-Goog-Api-Key": env.PLACES_API_KEY, "X-Goog-FieldMask": SEARCH_FIELDS },
      body: JSON.stringify(body),
    });
    if (!r.ok) throw new Error(`Places araması başarısız (${r.status}): ${(await r.text()).slice(0, 200)}`);
    const d = await r.json();
    out = out.concat(d.places || []);
    token = d.nextPageToken;
    if (!token) break;
    await new Promise((res) => setTimeout(res, 1500));
  }
  return out;
}

export async function placeDetails(env, id, fields = DETAIL_FIELDS) {
  const r = await fetch(`${base(env)}/places/${encodeURIComponent(id)}?languageCode=tr&regionCode=TR`, {
    headers: { "X-Goog-Api-Key": env.PLACES_API_KEY, "X-Goog-FieldMask": fields },
  });
  return r.ok ? r.json() : null;
}

export async function photoUri(env, name, width = 1000) {
  const r = await fetch(`${base(env)}/${name}/media?maxWidthPx=${width}&skipHttpRedirect=true`, {
    headers: { "X-Goog-Api-Key": env.PLACES_API_KEY },
  });
  if (!r.ok) return null;
  return (await r.json()).photoUri || null;
}
