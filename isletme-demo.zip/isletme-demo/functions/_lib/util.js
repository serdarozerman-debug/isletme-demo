export const esc = (s = "") => String(s)
  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
  .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

export const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
});

const TR = { ç: "c", ğ: "g", ı: "i", ö: "o", ş: "s", ü: "u", â: "a", î: "i", û: "u", İ: "i" };
export const slugify = (t = "") => t.replace(/[çğıöşüâîûİ]/gi, (c) => TR[c] || TR[c.toLowerCase()] || c)
  .toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40).replace(/-+$/, "");

export async function shortHash(s) {
  const b = await crypto.subtle.digest("SHA-1", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].slice(0, 2).map((x) => x.toString(16).padStart(2, "0")).join("");
}

export function waNumber(intl = "") {
  const d = String(intl).replace(/\D/g, "");
  return d.startsWith("905") && d.length === 12 ? d : null;
}

// "Web sitesi" alanına sosyal medya ya da kapanmış Google sitesi girilmiş işletmeler de aslında sitesiz.
const SOCIAL = {
  "instagram.com": "Instagram", "facebook.com": "Facebook", "fb.com": "Facebook",
  "m.facebook.com": "Facebook", "tiktok.com": "TikTok", "youtube.com": "YouTube",
  "x.com": "X", "twitter.com": "X", "linktr.ee": "Linktree", "wa.me": "WhatsApp",
  "whatsapp.com": "WhatsApp", "api.whatsapp.com": "WhatsApp", "linkr.bio": "Link sayfası",
  "bio.link": "Link sayfası", "business.site": "Eski Google sitesi (kapalı)",
};
export function siteType(url) {
  if (!url) return "";
  try {
    const h = new URL(url).hostname.replace(/^www\./, "");
    for (const [d, label] of Object.entries(SOCIAL)) if (h === d || h.endsWith("." + d)) return label;
    return "site";
  } catch { return ""; }
}

export function score(p) {
  const reviews = p.userRatingCount || 0, rating = p.rating || 0;
  let s = Math.log10(reviews + 1) * 40 + rating * 8;
  if (waNumber(p.internationalPhoneNumber)) s += 15;
  return Math.round(s * 10) / 10;
}

export const districtFrom = (address = "") => {
  const m = address.match(/\d{5}\s+([^,\/]+)\/([^,]+)/);
  return m ? `${m[1].trim()}, ${m[2].trim()}` : "";
};

export const nowIso = () => new Date().toISOString();

export const BOT_UA = /bot|crawler|spider|whatsapp|facebookexternalhit|telegram|slack|discord|preview|skype|linkedin/i;
