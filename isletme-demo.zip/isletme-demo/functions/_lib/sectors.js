// Yeni sektör eklemek = buraya bir kayıt eklemek. Şablon ortak.
export const SECTORS = {
  petshop: {
    label: "Petshop", query: "petshop",
    tagline: "Mama, aksesuar ve bakım ürünleri",
    items: [
      ["Kedi ve köpek maması", "Kuru, yaş ve özel diyet mamaları"],
      ["Kuş, balık ve kemirgen ürünleri", "Yem, kafes ve akvaryum malzemeleri"],
      ["Aksesuar ve oyuncak", "Tasma, yatak, taşıma çantası, oyuncak"],
      ["Bakım ve hijyen", "Kum, şampuan, tüy bakım ürünleri"],
    ],
    tint: "#DDEFFF", accent: "#F2A7B8", ink: "#1B2A4A", motif: "paws",
  },
  kuafor: {
    label: "Kadın kuaförü", query: "kadın kuaförü",
    tagline: "Saç kesimi, boya ve bakım",
    items: [
      ["Kesim ve fön", "Günlük ve özel gün şekillendirme"],
      ["Boya ve röfle", "Dip boya, balyaj, ombre"],
      ["Saç bakımı", "Keratin, nem ve onarım bakımları"],
      ["Gelin ve özel gün", "Topuz, örgü ve prova"],
    ],
    tint: "#F7E6EF", accent: "#B8336A", ink: "#2A1A24", motif: "dots",
  },
  berber: {
    label: "Berber", query: "berber",
    tagline: "Saç ve sakal tıraşı",
    items: [
      ["Saç kesimi", "Klasik ve modern kesimler"],
      ["Sakal tıraşı", "Ustura, şekillendirme ve bakım"],
      ["Cilt bakımı", "Maske ve yüz temizliği"],
      ["Çocuk tıraşı", "Sabırlı ve hızlı"],
    ],
    tint: "#EEF1F4", accent: "#1F4E8C", ink: "#14213D", motif: "stripes",
  },
  "oto-yikama": {
    label: "Oto yıkama", query: "oto yıkama",
    tagline: "Araç yıkama ve detaylı temizlik",
    items: [
      ["İç ve dış yıkama", "Köpüklü yıkama, kurulama, iç süpürme"],
      ["Detaylı temizlik", "Torpido, kapı içleri, jant"],
      ["Pasta ve cila", "Çizik giderme ve parlatma"],
      ["Koltuk yıkama", "Kumaş ve deri koltuk temizliği"],
    ],
    tint: "#E0F4F7", accent: "#0FA3B1", ink: "#0B2E3A", motif: "dots",
  },
  cicekci: {
    label: "Çiçekçi", query: "çiçekçi",
    tagline: "Çiçek, buket ve aranjman",
    items: [
      ["Buket ve aranjman", "Doğum günü, yıl dönümü, geçmiş olsun"],
      ["Saksı çiçekleri", "Orkide, sukulent ve iç mekan bitkileri"],
      ["Açılış ve tören", "Ayaklı çelenk ve sepetler"],
      ["Özel gün siparişleri", "Sevgililer Günü, Anneler Günü"],
    ],
    tint: "#EEF6E8", accent: "#E8618C", ink: "#23351D", motif: "dots",
  },
  kafe: {
    label: "Kafe", query: "kafe",
    tagline: "Kahve, kahvaltı ve tatlı",
    items: [
      ["Kahve", "Filtre, espresso bazlı ve Türk kahvesi"],
      ["Kahvaltı", "Serpme ve tabak kahvaltı"],
      ["Tatlı ve pasta", "Günlük taze ürünler"],
      ["Paket servis", "Gel al ve sipariş"],
    ],
    tint: "#E7EEF0", accent: "#8B5A3C", ink: "#2B1D14", motif: "dots",
  },
  diger: {
    label: "Diğer (kendin yaz)", query: "",
    tagline: "",
    items: [
      ["Ürün ve hizmetler", "İşletmenin sunduğu hizmetler burada listelenecek"],
      ["Deneyimli ekip", "Yılların tecrübesiyle hizmet"],
      ["Kolay ulaşım", "Arayın, yazın ya da uğrayın"],
    ],
    tint: "#EEF2F7", accent: "#3B6FD8", ink: "#1A2233", motif: "dots",
  },
};
