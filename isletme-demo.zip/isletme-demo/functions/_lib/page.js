import { placeDetails } from "./places.js";
import { renderSite } from "./render.js";
import { SECTORS } from "./sectors.js";

export const notFound = () => new Response(
  '<!doctype html><meta charset="utf-8"><meta name="robots" content="noindex"><p style="font-family:system-ui;padding:40px">Bu önizleme bulunamadı ya da kaldırıldı.</p>',
  { status: 404, headers: { "content-type": "text/html; charset=utf-8" } });

export async function renderPage(env, row, { sold, origin }) {
  const place = await placeDetails(env, row.place_id);
  if (!place || (place.businessStatus && place.businessStatus !== "OPERATIONAL")) return notFound();
  const html = renderSite({ place, sector: SECTORS[row.sector] || SECTORS.diger, slug: row.slug, env, sold, origin });
  const headers = { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" };
  if (!sold) headers["x-robots-tag"] = "noindex, nofollow";
  return new Response(html, { headers });
}
