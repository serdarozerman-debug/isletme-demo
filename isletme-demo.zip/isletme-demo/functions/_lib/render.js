import { esc, waNumber, districtFrom } from "./util.js";

const PAW = '<ellipse cx="0" cy="0" rx="14" ry="12"/><circle cx="-13" cy="-16" r="5"/><circle cx="-4" cy="-22" r="5"/><circle cx="6" cy="-22" r="5"/><circle cx="15" cy="-15" r="5"/>';

function motif(kind, color) {
  if (kind === "paws") {
    const pts = [[20, 110, -20], [120, 70, -10], [225, 105, 5], [330, 60, 15], [440, 95, 25]];
    return `<svg class="motif" viewBox="0 0 520 160" aria-hidden="true" fill="${color}">${pts.map(([x, y, r]) => `<g transform="translate(${x} ${y}) rotate(${r})">${PAW}</g>`).join("")}</svg>`;
  }
  if (kind === "stripes") {
    let s = "";
    for (let i = 0; i < 9; i++) s += `<rect x="${i * 60}" y="-40" width="22" height="260" transform="rotate(30 ${i * 60} 0)"/>`;
    return `<svg class="motif stripes" viewBox="0 0 520 160" aria-hidden="true" fill="${color}">${s}</svg>`;
  }
  let s = "";
  const r = [18, 10, 26, 8, 14, 22, 6, 12];
  for (let i = 0; i < 8; i++) s += `<circle cx="${30 + i * 62}" cy="${40 + ((i * 47) % 90)}" r="${r[i]}"/>`;
  return `<svg class="motif" viewBox="0 0 520 160" aria-hidden="true" fill="${color}">${s}</svg>`;
}

const stars = (n) => "★★★★★".slice(0, Math.round(n)) + "☆☆☆☆☆".slice(0, 5 - Math.round(n));

export function renderSite({ place, sector, slug, env, sold, origin }) {
  const name = place.displayName?.text || "";
  const intl = place.internationalPhoneNumber || "";
  const tel = intl.replace(/[^\d+]/g, "");
  const wa = waNumber(intl);
  const district = districtFrom(place.formattedAddress);
  const tagline = sector.tagline || place.primaryTypeDisplayName?.text || "";
  const maps = place.googleMapsUri || "#";
  const seller = env.SELLER_NAME || "So Works";
  const demoUrl = `${origin}/p/${slug}`;
  const sellerWa = env.SELLER_WA
    ? `https://wa.me/${env.SELLER_WA}?text=${encodeURIComponent(`Merhaba, ${name} için hazırlanan siteyle ilgileniyorum: ${demoUrl}`)}`
    : "#";

  const hours = place.regularOpeningHours?.weekdayDescriptions || [];
  const todayIdx = (new Date(Date.now() + 3 * 3600e3).getUTCDay() + 6) % 7; // Pazartesi = 0, TR saati
  const openNow = place.currentOpeningHours?.openNow;
  const photos = (place.photos || []).slice(0, 4);
  const reviews = (place.reviews || []).filter((r) => r.rating >= 4 && r.text?.text).slice(0, 3);
  const embed = env.MAPS_EMBED_KEY && place.id
    ? `https://www.google.com/maps/embed/v1/place?key=${encodeURIComponent(env.MAPS_EMBED_KEY)}&q=place_id:${encodeURIComponent(place.id)}&language=tr`
    : null;

  const ld = sold ? `<script type="application/ld+json">${JSON.stringify({
    "@context": "https://schema.org", "@type": "LocalBusiness", name,
    address: place.formattedAddress, telephone: intl || undefined, url: origin,
    aggregateRating: place.rating ? { "@type": "AggregateRating", ratingValue: place.rating, reviewCount: place.userRatingCount } : undefined,
  }).replace(/</g, "\\u003c")}</script>` : "";

  return `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
${sold ? "" : '<meta name="robots" content="noindex, nofollow">'}
<title>${esc(name)}${district ? " – " + esc(district) : ""}</title>
<meta name="description" content="${esc(`${name}${tagline ? ": " + tagline : ""}. ${place.formattedAddress || ""}`)}">
<meta property="og:title" content="${esc(name)}">
<meta property="og:description" content="${esc(tagline || district)}">
<meta name="theme-color" content="${sector.tint}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@600;800&family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
${ld}
<style>
:root{--tint:${sector.tint};--accent:${sector.accent};--ink:${sector.ink};--muted:#5A6478;--mist:#F5F7FA;--line:#E3E8F0;--white:#fff}
*{box-sizing:border-box;margin:0}
html{scroll-behavior:smooth}
body{font-family:"Nunito Sans",system-ui,sans-serif;color:var(--ink);background:var(--white);line-height:1.55;font-size:17px}
a{color:inherit}
img{max-width:100%;display:block}
:focus-visible{outline:3px solid var(--ink);outline-offset:3px;border-radius:6px}
.wrap{max-width:1000px;margin:0 auto;padding:0 22px}
h1,h2{font-family:"Baloo 2",sans-serif;font-weight:800;line-height:1}
h2{font-size:clamp(28px,4.5vw,40px);margin-bottom:20px}

.demo{background:#FFC845;color:#1A1A1A;font-size:15px;padding:10px 0}
.demo .wrap{display:flex;gap:10px 16px;flex-wrap:wrap;align-items:center;justify-content:space-between}
.demo a{font-weight:700;background:#1A1A1A;color:#fff;padding:6px 12px;border-radius:8px;text-decoration:none}

.hero{background:var(--tint);padding:60px 0 92px;position:relative;overflow:hidden}
.hero>.wrap{position:relative;z-index:1}
.hero h1{font-size:clamp(44px,9vw,96px);letter-spacing:-.02em;max-width:13ch}
.tag{margin-top:14px;font-size:19px;color:var(--muted)}
.meta{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}
.chip{display:inline-flex;gap:8px;align-items:center;background:var(--white);padding:6px 14px;border-radius:999px;font-weight:700;font-size:15px}
.chip .st{color:#E8A400;letter-spacing:1px}
.chip.open::before,.chip.closed::before{content:"";width:9px;height:9px;border-radius:50%;background:#2DA44E}
.chip.closed::before{background:#C9372C}
.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:28px}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:14px 22px;border-radius:14px;font-weight:700;text-decoration:none;font-size:17px;border:2px solid var(--ink);cursor:pointer;font-family:inherit}
.btn.solid{background:var(--ink);color:var(--white)}
.btn.ghost{background:var(--white);color:var(--ink)}
.btn.accent{background:var(--accent);border-color:var(--accent);color:var(--ink)}
.motif{position:absolute;right:-20px;bottom:6px;width:min(540px,72vw);pointer-events:none}
.motif>*{opacity:0;animation:in .5s ease forwards}
${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => `.motif>*:nth-child(${i}){animation-delay:${(0.15 + i * 0.2).toFixed(2)}s}`).join("")}
.motif.stripes{opacity:.35}
@keyframes in{to{opacity:1}}
@media (prefers-reduced-motion:reduce){.motif>*{animation:none;opacity:1}html{scroll-behavior:auto}}

.photos{margin-top:-56px;position:relative;z-index:2}
.strip{display:grid;grid-auto-flow:column;grid-auto-columns:minmax(240px,1fr);gap:12px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:6px}
.strip figure{scroll-snap-align:start;border-radius:18px;overflow:hidden;background:var(--mist);position:relative;aspect-ratio:4/3}
.strip img{width:100%;height:100%;object-fit:cover}
.strip figcaption{position:absolute;left:8px;bottom:8px;font-size:11px;background:rgba(255,255,255,.88);padding:2px 8px;border-radius:6px}

section.block{padding:56px 0}
.grid{display:grid;grid-template-columns:1.2fr 1fr;gap:48px}
@media (max-width:780px){.grid{grid-template-columns:1fr;gap:36px}}
ul.items{list-style:none;padding:0}
ul.items li{padding:16px 0 16px 34px;border-bottom:1px solid var(--line);position:relative}
ul.items li::before{content:"";position:absolute;left:4px;top:23px;width:14px;height:14px;border-radius:50%;background:var(--accent)}
ul.items b{display:block;font-size:18px}
ul.items span{color:var(--muted)}

.visit{background:var(--mist);border-radius:20px;padding:26px}
.visit address{font-style:normal;margin-bottom:14px}
table.hours{width:100%;border-collapse:collapse;font-size:15px;margin:4px 0 20px}
table.hours td{padding:6px 0;border-bottom:1px dashed #D5DCE6}
table.hours td:last-child{text-align:right;color:var(--muted)}
table.hours tr.today td{font-weight:700;color:var(--ink)}
.map{margin-top:18px;border-radius:14px;overflow:hidden;aspect-ratio:4/3;background:#E9EDF2}
.map iframe{width:100%;height:100%;border:0}

.reviews{background:var(--tint)}
.rv{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px}
.rv blockquote{background:var(--white);border-radius:18px;padding:22px}
.rv .st{color:#E8A400;letter-spacing:1px}
.rv p{margin:10px 0 14px}
.rv cite{font-style:normal;font-size:14px;color:var(--muted)}

footer{padding:32px 0 48px;font-size:14px;color:var(--muted)}
footer p+p{margin-top:8px}
footer button{background:none;border:0;padding:0;font:inherit;color:inherit;text-decoration:underline;cursor:pointer}

.bar{display:none}
@media (max-width:780px){
  .bar{display:flex;gap:10px;position:fixed;left:0;right:0;bottom:0;padding:10px 14px calc(10px + env(safe-area-inset-bottom));background:rgba(255,255,255,.96);border-top:1px solid var(--line);z-index:10}
  .bar .btn{flex:1;padding:12px}
  body{padding-bottom:84px}
}
</style>
</head>
<body>
${sold ? "" : `<div class="demo" role="note"><div class="wrap"><span>Bu sayfa ${esc(name)} için hazırlanmış bir önizlemedir.</span><a href="${esc(sellerWa)}" target="_blank" rel="noopener">Bu siteyi istiyorum</a></div></div>`}

<header class="hero">
  <div class="wrap">
    <h1>${esc(name)}</h1>
    <p class="tag">${esc([tagline, district].filter(Boolean).join(". "))}</p>
    <div class="meta">
      ${openNow === true ? '<span class="chip open">Şu an açık</span>' : openNow === false ? '<span class="chip closed">Şu an kapalı</span>' : ""}
      ${place.rating ? `<span class="chip"><span class="st" aria-hidden="true">★</span>${esc(place.rating.toFixed(1))} puan, ${esc(place.userRatingCount || 0)} Google yorumu</span>` : ""}
    </div>
    <div class="actions">
      ${tel ? `<a class="btn solid" href="tel:${esc(tel)}">Hemen ara</a>` : ""}
      ${wa ? `<a class="btn ghost" href="https://wa.me/${wa}" target="_blank" rel="noopener">WhatsApp'tan yaz</a>` : ""}
      <a class="btn ghost" href="#ziyaret">Yol tarifi</a>
    </div>
  </div>
  ${motif(sector.motif, sector.accent)}
</header>

${photos.length ? `<div class="photos"><div class="wrap"><div class="strip">${photos.map((p, i) => {
  const a = p.authorAttributions?.[0];
  return `<figure><img src="/img?n=${encodeURIComponent(p.name)}" alt="${esc(name)} fotoğraf ${i + 1}" loading="${i ? "lazy" : "eager"}" width="400" height="300">${a ? `<figcaption>Fotoğraf: ${a.uri ? `<a href="${esc(a.uri)}" target="_blank" rel="noopener">${esc(a.displayName)}</a>` : esc(a.displayName)}</figcaption>` : ""}</figure>`;
}).join("")}</div></div></div>` : ""}

<main>
  <section class="block">
    <div class="wrap grid">
      <div>
        <h2>Neler sunuyoruz</h2>
        <ul class="items">${sector.items.map(([t, d]) => `<li><b>${esc(t)}</b><span>${esc(d)}</span></li>`).join("")}</ul>
      </div>
      <aside class="visit" id="ziyaret">
        <h2>Bizi ziyaret edin</h2>
        <address>${esc(place.formattedAddress || "")}</address>
        ${hours.length ? `<table class="hours"><tbody>${hours.map((d, i) => {
          const k = d.indexOf(":");
          return `<tr${i === todayIdx ? ' class="today"' : ""}><td>${esc(d.slice(0, k))}</td><td>${esc(d.slice(k + 1).trim())}</td></tr>`;
        }).join("")}</tbody></table>` : ""}
        <a class="btn accent" href="${esc(maps)}" target="_blank" rel="noopener">Google Haritalar'da aç</a>
        ${embed ? `<div class="map"><iframe src="${esc(embed)}" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="${esc(name)} konumu"></iframe></div>` : ""}
      </aside>
    </div>
  </section>

  ${reviews.length ? `<section class="block reviews"><div class="wrap">
    <h2>Müşterilerimiz ne diyor</h2>
    <div class="rv">${reviews.map((r) => {
      const t = r.text.text.length > 260 ? r.text.text.slice(0, 257).trimEnd() + "…" : r.text.text;
      const a = r.authorAttribution || {};
      return `<blockquote><span class="st" aria-label="${r.rating} yıldız">${stars(r.rating)}</span><p>${esc(t)}</p><cite>${a.uri ? `<a href="${esc(a.uri)}" target="_blank" rel="noopener">${esc(a.displayName || "Google kullanıcısı")}</a>` : esc(a.displayName || "Google kullanıcısı")}${r.relativePublishTimeDescription ? ", " + esc(r.relativePublishTimeDescription) : ""}</cite></blockquote>`;
    }).join("")}</div>
  </div></section>` : ""}
</main>

<footer>
  <div class="wrap">
    <p>İşletme bilgileri, fotoğraflar ve yorumlar Google Haritalar'dan alınmıştır.${sold ? "" : " Hizmet listesi örnek içeriktir."}</p>
    ${sold
      ? `<p>Site: ${esc(seller)}</p>`
      : `<p><button type="button" id="optout">Bu önizlemenin kaldırılmasını isteyin</button></p>`}
  </div>
</footer>

<nav class="bar" aria-label="Hızlı iletişim">
  ${tel ? `<a class="btn solid" href="tel:${esc(tel)}">Ara</a>` : ""}
  ${wa ? `<a class="btn ghost" href="https://wa.me/${wa}" target="_blank" rel="noopener">WhatsApp</a>` : `<a class="btn ghost" href="${esc(maps)}" target="_blank" rel="noopener">Yol tarifi</a>`}
</nav>
${sold ? "" : `<script>
document.getElementById("optout").addEventListener("click", async (e) => {
  if (!confirm("Bu önizleme kalıcı olarak kaldırılsın ve sizinle bir daha bu konuda iletişime geçilmesin mi?")) return;
  const r = await fetch("/api/optout/${esc(slug)}", { method: "POST" });
  e.target.closest("p").textContent = r.ok ? "Önizleme kaldırıldı. Sizinle bu konuda tekrar iletişime geçilmeyecek." : "İşlem tamamlanamadı. Lütfen tekrar deneyin.";
});
</script>`}
</body>
</html>`;
}
