import { json, nowIso } from "../../_lib/util.js";

// İşletme demo sayfasından "kaldırılmasını isteyin" dediğinde.
export async function onRequestPost({ params, env }) {
  const r = await env.DB.prepare(
    "UPDATE leads SET status = 'ret', note = TRIM(note || ' [demo sayfasından ret]'), updated_at = ? WHERE slug = ? AND status != 'satildi'",
  ).bind(nowIso(), params.slug).run();
  return r.meta.changes ? json({ ok: true }) : json({ ok: false }, 404);
}
