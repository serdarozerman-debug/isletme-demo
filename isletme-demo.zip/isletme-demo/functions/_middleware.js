import { renderPage } from "./_lib/page.js";

function unauthorized() {
  return new Response("Giriş gerekli", { status: 401, headers: { "WWW-Authenticate": 'Basic realm="admin", charset="UTF-8"' } });
}

export async function onRequest({ request, env, next }) {
  const url = new URL(request.url);
  const host = url.hostname.replace(/^www\./, "");

  // Satılan işletmenin kendi alan adı: aynı şablon, önizleme şeridi yok, Google'a açık.
  if (env.MAIN_HOST && host !== env.MAIN_HOST && !host.endsWith(".pages.dev") && host !== "localhost") {
    const row = await env.DB.prepare(
      "SELECT l.place_id, l.slug, l.sector FROM domains d JOIN leads l ON l.slug = d.slug WHERE d.hostname = ?",
    ).bind(host).first();
    if (row) {
      if (url.pathname === "/robots.txt") return new Response(`User-agent: *\nAllow: /\nSitemap: ${url.origin}/sitemap.xml\n`);
      if (url.pathname === "/sitemap.xml") return new Response(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${url.origin}/</loc></url></urlset>`, { headers: { "content-type": "application/xml" } });
      if (url.pathname.startsWith("/img")) return next();
      if (url.pathname !== "/") return Response.redirect(`${url.origin}/`, 301);
      return renderPage(env, row, { sold: true, origin: url.origin });
    }
  }

  // Admin paneli ve API'si şifreli.
  if (url.pathname === "/admin" || url.pathname.startsWith("/admin/")) {
    const expected = "Basic " + btoa(`${env.ADMIN_USER || "admin"}:${env.ADMIN_PASS || ""}`);
    if (!env.ADMIN_PASS || request.headers.get("Authorization") !== expected) return unauthorized();
  }
  return next();
}
