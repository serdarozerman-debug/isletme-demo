import { photoUri } from "./_lib/places.js";

// /img?n=places/{id}/photos/{ref}  -> anahtarı göstermeden Google fotoğrafına yönlendirir.
export async function onRequestGet({ request, env }) {
  const n = new URL(request.url).searchParams.get("n") || "";
  const m = n.match(/^places\/([^/]+)\/photos\/[^/]+$/);
  if (!m) return new Response("Geçersiz istek", { status: 400 });
  const row = await env.DB.prepare("SELECT status FROM leads WHERE place_id = ?").bind(m[1]).first();
  if (!row || row.status === "ret") return new Response("Bulunamadı", { status: 404 });
  const uri = await photoUri(env, n);
  if (!uri) return new Response("Fotoğraf alınamadı", { status: 502 });
  return new Response(null, { status: 302, headers: { location: uri, "cache-control": "private, max-age=3600" } });
}
