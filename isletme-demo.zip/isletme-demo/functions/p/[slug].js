import { renderPage, notFound } from "../_lib/page.js";
import { BOT_UA, nowIso } from "../_lib/util.js";

export async function onRequestGet({ params, env, request }) {
  const row = await env.DB.prepare("SELECT place_id, slug, sector, status FROM leads WHERE slug = ?").bind(params.slug).first();
  if (!row || row.status === "ret") return notFound();

  const url = new URL(request.url);
  const ua = request.headers.get("user-agent") || "";
  // Kendi önizlemelerimiz (?preview=1) ve WhatsApp link önizlemesi gibi botlar sayılmaz.
  if (!url.searchParams.has("preview") && !BOT_UA.test(ua)) {
    await env.DB.prepare("UPDATE leads SET views = views + 1, last_view = ? WHERE slug = ?").bind(nowIso(), row.slug).run();
  }
  return renderPage(env, row, { sold: false, origin: url.origin });
}
