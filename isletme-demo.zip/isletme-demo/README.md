# İşletme Demo (So Works)

Tamamı Cloudflare'de çalışır: admin paneli, demo siteler, satılan siteler ve veritabanı (D1).
Bilgisayarda hiçbir şey çalışmaz; panel telefondan da kullanılır.

## Adresler
- https://MAIN_HOST/admin/        Tarama ve lead takibi (şifreli)
- https://MAIN_HOST/p/<slug>      İşletmeye gönderilen demo
- https://isletmeninalanadi.com   Satış sonrası aynı site, önizleme şeridi olmadan

## Kurulum (tarayıcıdan, bir kez)
1. Bu klasörü bir GitHub reposuna yükle.
2. Cloudflare > Storage & Databases > D1 > "isletme-demo" adlı veritabanı oluştur.
   Console sekmesine schema.sql içeriğini yapıştırıp çalıştır. Veritabanı ID'sini wrangler.toml'a yaz.
3. Cloudflare > Workers & Pages > Create > Pages > Connect to Git > repoyu seç.
   Build komutu boş, çıktı klasörü: public.
4. Proje > Settings > Variables and Secrets:
   PLACES_API_KEY (secret), ADMIN_PASS (secret), MAPS_EMBED_KEY (opsiyonel).
   wrangler.toml'daki MAIN_HOST, SELLER_WA, SELLER_NAME değerlerini düzenle.
5. Proje > Custom domains > MAIN_HOST'u ekle (ör. demo.soworks.com.tr).
Bundan sonra GitHub'a her push otomatik yayına alınır.

## Google Cloud
- Places API (New): sunucu anahtarı, yalnızca bu API ile sınırlı.
- Maps Embed API (opsiyonel, ücretsiz): ayrı anahtar, HTTP referrer kısıtıyla.

## Satış sonrası
Leadler sekmesinde durumu "Satıldı" yap > "Alan adı bağla". Ardından Cloudflare Pages >
Custom domains'e işletmenin alan adını ekle. Site Google'a açılır (noindex kalkar, sitemap ve LocalBusiness verisi eklenir).

## Yeni sektör
functions/_lib/sectors.js'e bir kayıt ekle (başlık, hizmet listesi, renkler). Şablon ortak.

## Veri
D1'de yalnızca place_id ve takip alanları (durum, not, görüntülenme) tutulur. İşletme bilgileri,
fotoğraflar ve yorumlar her açılışta Google'dan canlı çekilir.
